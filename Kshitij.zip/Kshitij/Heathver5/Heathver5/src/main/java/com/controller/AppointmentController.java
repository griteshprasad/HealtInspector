package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.patient;
import com.service.AppointmentService;

@Controller
public class AppointmentController {
	
	
	@Autowired
	private AppointmentService appointment;
	
	@RequestMapping(value = "/appointment", method = RequestMethod.POST)
	public ModelAndView bookAppointment(@RequestParam("name")String name,@RequestParam("age")int age,@RequestParam("gender")String gender,@RequestParam("hospital")String hospital,@RequestParam("mobile")String mobile,@RequestParam("city")String city,@RequestParam("facility")String facility,@RequestParam("date")String date,@RequestParam("rec")String docname,@RequestParam("user")String username) {
	
		patient p = new patient();
		p.setAge(age);
		p.setCity(city);
		p.setFacilityRequired(facility);
		p.setName(name);
		p.setMobile(mobile);
		p.setDate(date);
		p.setGender(gender);
		p.setDocname(docname);
		p.setUsername(username);
		
		
		p.setHospitalName(hospital);
		boolean isValid = appointment.patientDetails(p);
        
		return new ModelAndView("searchResult");
	}

}

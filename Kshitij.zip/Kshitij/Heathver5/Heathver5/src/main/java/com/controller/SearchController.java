package com.controller;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.doctor;
import com.service.SearchService;

@Controller
 
public class SearchController {

	@Autowired
	private SearchService search;	
	
	
	private static Logger log = Logger.getLogger(SearchController.class);

	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView validateUsr(@RequestParam("specialization")String specialization,@RequestParam("clinic")String clinic) {
		String msg = "";
		
		System.out.println("Specialization : "+specialization + " Clinic : "+clinic);
		List<doctor> userObj = search.findUser(specialization, clinic);
		
		System.out.println("In the SearchController..");
		for (doctor dObj : userObj)
		{
			System.out.println(dObj.getFirstName());
		}
		
        return new ModelAndView("searchResult","DoctorList", userObj);
		
		
	}
	
}
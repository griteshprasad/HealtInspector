package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.doctor;
import com.pojo.patient;
import com.pojo.User;
import com.pojo.chat;
import com.service.AuthService;
import com.service.ChatService;
import com.service.DocAuthService;
import com.service.SearchService;

@Controller
@SessionAttributes("user")
@RequestMapping(value = "/user")
public class LoginCtrl {

	@Autowired
	private AuthService authenticateService;	
	
	@Autowired
	private DocAuthService docauthenticateService;
	
	@Autowired
	private SearchService search;
	
	@Autowired
	private ChatService chatservice;
	
	private static Logger log = Logger.getLogger(LoginCtrl.class);

	// Checks if the user credentials are valid or not.
	
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public ModelAndView validateUsr(@RequestParam("username")String username,@RequestParam("password")String password,HttpSession session) {
		String msg = "";
		boolean isValid = authenticateService.findUser(username, password);
		log.info("Is user valid?= " + isValid);
		ModelAndView mv= new ModelAndView();
        
		
		if(isValid) {
			msg="Login Succesful !";
			docauthenticateService.online(username);
			session.setAttribute("username", username);
		    mv.addObject("output", msg);
			mv.addObject("user", username);
			mv.setViewName("home");
			return mv;
		} else {
			msg = "Invalid credentials";
			return new ModelAndView("home", "output", msg);
		}
	}
	@RequestMapping(value = "/chatPage", method = RequestMethod.POST)
	public ModelAndView chatPage(HttpSession session){
		ModelAndView mv= new ModelAndView();
		List<doctor> userObj = search.findOnlineDoctor();
		String username=(String) session.getAttribute("username");
		List<chat> chat = chatservice.chat(username);
		mv.addObject("reciever", chat);
		mv.addObject("onlineUser",userObj);
		mv.setViewName("home");
		return mv;
		
	}
	@RequestMapping(value = "/docvalidate", method = RequestMethod.POST)
	public ModelAndView validateDoctor(@RequestParam("username")String username,@RequestParam("password")String password,HttpSession session) {
		String msg = "";
		boolean isValid = docauthenticateService.findDoctor(username, password);
		log.info("Is user valid?= " + isValid);
		ModelAndView mv= new ModelAndView();
        
		
		if(isValid) {
			msg="Login Succesful !";
			authenticateService.online(username);
			session.setAttribute("username", username);
			mv.addObject("user", username);
			List<patient> doc = docauthenticateService.dashboard(username);
			mv.addObject("dashboard", doc);
			mv.addObject("output", msg);
			mv.setViewName("doctorDashboard");
			return mv;
		} else {
			msg = "Invalid credentials";
			return new ModelAndView("doctorDashboard", "output", msg);
		}
	}
	@RequestMapping(value = "/docchatPage", method = RequestMethod.POST)
	public ModelAndView docchatPage(HttpSession session){
		ModelAndView mv= new ModelAndView();
		List<User> userObj = search.findOnlineUser();
		String username=(String) session.getAttribute("username");
		List<chat> chat = chatservice.chat(username);
		List<patient> doc = docauthenticateService.dashboard(username);
		mv.addObject("dashboard", doc);
		mv.addObject("onlineUser",userObj);
		mv.addObject("reciever", chat);
		mv.setViewName("doctorDashboard");
		return mv;
		
	}
	 @RequestMapping(value = "/logout",method=RequestMethod.GET)
     public ModelAndView logout(HttpSession session) {
		 String out="Sucessfully Logout";
		 String msg = null;
       session.invalidate();
       ModelAndView mv1= new ModelAndView();
       mv1.addObject("output", out);
       mv1.addObject("user", msg);
       mv1.setViewName("home");
       return mv1;
     }
	 @RequestMapping(value = "/chat",method=RequestMethod.POST)
     public ModelAndView chat(@RequestParam("rec")String reciever, @RequestParam("msg")String text,HttpSession session) {
		 
       String username=(String) session.getAttribute("username");
      chat obj = new chat();
      obj.setSender(username);
      obj.setReciever(reciever);
      obj.setMsg(text);
      chatservice.chatUser(obj);
      ModelAndView mv= new ModelAndView();
      mv.setViewName("home");
      
       return mv;
     }
	 @RequestMapping(value = "/docChat",method=RequestMethod.POST)
     public ModelAndView docchat(@RequestParam("rec")String reciever, @RequestParam("msg")String text,HttpSession session) {
		 
       String username=(String) session.getAttribute("username");
      chat obj = new chat();
      obj.setSender(username);
      obj.setReciever(reciever);
      obj.setMsg(text);
      chatservice.chatUser(obj);
      ModelAndView mv= new ModelAndView();
      mv.setViewName("doctorDashboard");
      
       return mv;
     }
	 @RequestMapping(value = "/refresh", method = RequestMethod.POST)
	 public ModelAndView refresh(HttpSession session) {
		 String username=(String) session.getAttribute("username");
		 List<chat> userObj = chatservice.chat(username);
		 ModelAndView mv= new ModelAndView();
		 mv.addObject("onlineUser",userObj);
			mv.setViewName("doctorDashboard");
			return mv;
		 
		 
		 
	 }
	 
  
	
}
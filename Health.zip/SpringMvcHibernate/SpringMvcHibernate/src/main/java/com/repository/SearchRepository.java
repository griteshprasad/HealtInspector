package com.repository;

import java.util.Date;
import java.util.List;
import java.util.UUID;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pojo.doctor;

@Repository
@SuppressWarnings("unchecked")
public class SearchRepository
{
   @Autowired
   private SessionFactory mySessionFactory;
   @Transactional
   public List<doctor> searchDoc(String searchText) throws Exception
   {
      try
      {
         Session session = mySessionFactory.getCurrentSession();
         
         FullTextSession fullTextSession = Search.getFullTextSession(session);

         QueryBuilder qb = fullTextSession.getSearchFactory()
           .buildQueryBuilder().forEntity(doctor.class).get();
         org.apache.lucene.search.Query query = qb
           .keyword().onFields("clinic", "specialization", "first_name")
           .matching(searchText)
           .createQuery();

         org.hibernate.Query hibQuery = 
            fullTextSession.createFullTextQuery(query, doctor.class);

         List<doctor> results = hibQuery.list();
         return results;
      }
      catch(Exception e)
      {
         throw e;
      }
   }
}

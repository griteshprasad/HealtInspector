package com.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateTemplate;


import com.pojo.chat;

public class ChatService {
	
	 private HibernateTemplate hibernateTemplate;
     private static Logger log = Logger.getLogger(RegistrationService.class);
 
     private ChatService() { }
 
     public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
         this.hibernateTemplate = hibernateTemplate;
     }

     
     @SuppressWarnings( { "unchecked", "deprecation" } )
     public boolean chatUser(chat obj)
     {
        
        
        hibernateTemplate.save(obj);
           
        
        
        return true;
        
        
     }
     @SuppressWarnings( { "unchecked", "deprecation" } )
     public List<chat> chat(String reciever){
    	// String sql = "SELECT * FROM chat where reciever='"+reciever+"' order by id desc";
 		
 		
 		Session session = hibernateTemplate.getSessionFactory().openSession();
 		session.beginTransaction();
 		 
 		
 		
 		String sql = "SELECT * FROM chat where reciever='"+reciever+"' order by id desc limit 5";
 		SQLQuery query = session.createSQLQuery(sql);
 		query.addEntity(chat.class);
 		 
 		List results = query.list();
 		
 		return results;
     }
     @SuppressWarnings( { "unchecked", "deprecation" } )
     public List<chat> chatSend(String sender){
    	 String sqlQuery = "from chat as c where c.sender=?";
    	 
    	 List<chat> userObj = (List<chat>) hibernateTemplate.find(sqlQuery,sender);
    	 return userObj;
     }


}

var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 500);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

function form3() {
    var fname = document.getElementById("fname3");
    var lname = document.getElementById("lname3");
    var gender = document.getElementById("gender3");
	var contact = document.getElementById("contact3");
	var email = document.getElementById("email3");
	var uname = document.getElementById("name3");
	var pwd = document.getElementById("pwd3");
	
	 var letters = /^[A-Za-z]+$/;
	 var numbers = /^[0-9]+$/;
	 var pass = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
	 var alnum = /^[A-Za-z0-9]+$/;
	 var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	 
	 
	/******FIRSTNAME******/
	
	if(fname.value == ""){
		alert("Firstname should not be empty.");
		fname.focus();
		return false;
	}
	else if(!(fname.value.match(letters))){
		alert("Firstname must only contain letters.");
		fname.focus();
		return false;
	}
	if(lname.value == ""){
		alert("Lastname should not be empty.");
		lname.focus();
		return false;
	}
	else if(!(lname.value.match(letters))){
		alert("Lastname must only contain letters.");
		lname.focus();
		return false;
	}
	if(gender.value == ""){
		alert("Please select gender.");
		gender.focus();
		return false;
	}
	if(contact.value == ""){
		alert("Contact should not be empty.");
		contact.focus();
		return false;
	}
	else if(!(contact.value.match(numbers))){
		alert("Contact must only contain digits.");
		contact.focus();
		return false;
	}
	else if(contact.value.length < 10){
		alert("Contact must be 10 digits long.");
		contact.focus();
		return false;
	}
	if(email.value == ""){
		alert("Email should not be empty.");
		email.focus();
		return false;
	}
	else if(!(email.value.match(mail))){
		alert("Invalid email id.");
		email.focus();
		return false;
	}
	if(uname.value == ""){
		alert("Username should not be empty.");
		uname.focus();
		return false;
	}
	else if(uname.value.length < 6){
		alert("Username must be atleast 6 characters long.");
		uname.focus();
		return false;
	}
	else if(!(uname.value.match(alnum))){
		alert("Username only contains letters and numbers (no special characters)");
		uname.focus();
		return false;
	}
	if(pwd.value == ""){
		alert("Password should not be empty.");
		pwd.focus();
		return false;
	}
	else if(pwd.value.length < 8){
		alert("Password must be atleast 8 characters long.");
		pwd.focus();
		return false;
	}
	else if(!(pwd.value.match(pass))){
		alert("Password : \nContains at least 1 numberContains at least 1 lowercase letter\nContains at least 1 uppercase letter\nContains a special character (e.g. @ !)");
		pwd.focus();
		return false;
	}
    
	return true;
    
}
function form4() {
    var fname = document.getElementById("fname4");
    var lname = document.getElementById("lname4");
	var specialization = document.getElementById("specialization4");
	var practice = document.getElementById("practice4");
	var clinic = document.getElementById("clinic4");
	var contact = document.getElementById("contact4");
	var email = document.getElementById("email4");
	var uname = document.getElementById("name4");
	var pwd = document.getElementById("pwd4");
	
	 var letters = /^[A-Za-z]+$/;
	 var numbers = /^[0-9]+$/;
	 var pass = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
	 var alnum = /^[A-Za-z0-9]+$/;
	 var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	 
	 
	
	
	if(fname.value == ""){
		alert("Firstname should not be empty.");
		fname.focus();
		return false;
	}
	else if(!(fname.value.match(letters))){
		alert("Firstname must only contain letters.");
		fname.focus();
		return false;
	}
	
	
	
	
	if(lname.value == ""){
		alert("Lastname should not be empty.");
		lname.focus();
		return false;
	}
	else if(!(lname.value.match(letters))){
		alert("Lastname must only contain letters.");
		lname.focus();
		return false;
	}
	
	
		
	
	if(specialization.value == ""){
		alert("Specialization should not be empty.");
		specialization.focus();
		return false;
	}
	else if(!(specialization.value.match(letters))){
		alert("Specialization must only contain letters.");
		specialization.focus();
		return false;
	}
	
		
		
	
	if(practice.value == ""){
		alert("Practice should not be empty.");
		practice.focus();
		return false;
	}
	else if(!(practice.value.match(letters))){
		alert("Practice must only contain letters.");
		practice.focus();
		return false;
	}
		
		
		
	
	if(clinic.value == ""){
		alert("Clinic should not be empty.");
		clinic.focus();
		return false;
	}
	else if(!(clinic.value.match(letters))){
		alert("Clinic must only contain letters.");
		clinic.focus();
		return false;
	}
		
		
		
		
		if(contact.value == ""){
			alert("Contact should not be empty.");
			contact.focus();
			return false;
		}
		else if(!(contact.value.match(numbers))){
			alert("Contact must only contain digits.");
			contact.focus();
			return false;
		}
		else if(contact.value.length < 10){
			alert("Contact must be 10 digits long.");
			contact.focus();
			return false;
		}
    
    
   
	
	if(email.value == ""){
		alert("Email should not be empty.");
		email.focus();
		return false;
	}
	else if(!(email.value.match(mail))){
		alert("Invalid email id.");
		email.focus();
		return false;
	}
    
   
    
 	
	
	if(uname.value == ""){
		alert("Username should not be empty.");
		uname.focus();
		return false;
	}
	else if(uname.value.length < 6){
		alert("Username must be atleast 6 characters long.");
		uname.focus();
		return false;
	}
	else if(!(uname.value.match(alnum))){
		alert("Username only contains letters and numbers (no special characters)");
		uname.focus();
		return false;
	}
    
    
	
	
	if(pwd.value == ""){
		alert("Password should not be empty.");
		pwd.focus();
		return false;
	}
	else if(pwd.value.length < 8){
		alert("Password must be atleast 8 characters long.");
		pwd.focus();
		return false;
	}
	else if(!(pwd.value.match(pass))){
		alert("Password : \nContains at least 1 numberContains at least 1 lowercase letter\nContains at least 1 uppercase letter\nContains a special character (e.g. @ !)");
		pwd.focus();
		return false;
	}
    
	return true;
    
}

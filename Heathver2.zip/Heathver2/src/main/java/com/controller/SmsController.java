package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

@Controller
public class SmsController {
	
	 public static final String ACCOUNT_SID = "ACd635bd3d53229b3294493c9e9e3f9197";
	 public static final String AUTH_TOKEN = "57475544f5cf239298988b387edb45ae";
	 public static final String TWILIO_NUMBER = "+18635937535";
	 
	 
	 @RequestMapping(value = "/sendSms", method = RequestMethod.POST)
	 public ModelAndView greeting() {
	        sendSMS();
	        return new ModelAndView("greeting");
	 }
	 
	 public void sendSMS() {
		    try {
		        TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN);

		        // Build a filter for the MessageList
		        List<NameValuePair> params = new ArrayList<NameValuePair>();
		        params.add(new BasicNameValuePair("Body", "Hello, World!"));
		        params.add(new BasicNameValuePair("To", "+918084708452")); //Add real number here
		        params.add(new BasicNameValuePair("From", TWILIO_NUMBER));

		        MessageFactory messageFactory = client.getAccount().getMessageFactory();
		        Message message = messageFactory.create(params);
		        System.out.println(message.getSid());
		    } 
		    catch (TwilioRestException e) {
		        System.out.println(e.getErrorMessage());
		    }
		}


}

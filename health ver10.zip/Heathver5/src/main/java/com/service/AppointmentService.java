package com.service;

import org.springframework.orm.hibernate5.HibernateTemplate;


import com.pojo.patient;

public class AppointmentService {
	 private HibernateTemplate hibernateTemplate;
	 
	 private AppointmentService(){}
	 
	 public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
         this.hibernateTemplate = hibernateTemplate;
     }
	 @SuppressWarnings( { "unchecked", "deprecation" } )
     public boolean patientDetails(patient obj)
     {
        
        
        hibernateTemplate.save(obj);
            //hibernateTemplate.getSessionFactory().getCurrentSession().getTransaction().commit();
        
        
        return true;
        
        
     }

}

package com.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.pojo.User;
import com.pojo.doctor;

public class AuthService {

	private HibernateTemplate hibernateTemplate;
	private static Logger log = Logger.getLogger(AuthService.class);

	private AuthService() { }

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@SuppressWarnings( { "unchecked", "deprecation" } )
	public boolean findUser(String uname,String upwd) {
		log.info("Checking the user in the database");
		boolean isValidUser = false;
		String sqlQuery = "from User u where u.name=? and u.password=?";
		try {
			List<User> userObj = (List<User>) hibernateTemplate.find(sqlQuery, uname, upwd);
			if(userObj != null && userObj.size() > 0) {
				log.info("Id= " + userObj.get(0).getId() + ", Name= " + userObj.get(0).getName() + ", Password= " + userObj.get(0).getPassword());
				isValidUser = true;
			}
		} catch(Exception e) {
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);	
		}
		return isValidUser;
	}
	@SuppressWarnings("deprecation")
	public int online(String username){
		String sql = "update doctor set status='Active' where user_name='"+username+"'";
		//hibernateTemplate.bulkUpdate(sql,"Active", username);
		
		Session session = hibernateTemplate.getSessionFactory().openSession();
		session.beginTransaction();
		Query<?> query =  session.createQuery(sql);
		int result = query.executeUpdate();
		session.getTransaction().commit();
		session.close();
		
		
		return 1;
	}
	@SuppressWarnings("deprecation")
	public int offline(String username){
		String sql = "update doctor set status='Inactive' where user_name='"+username+"'";
		
		
		Session session = hibernateTemplate.getSessionFactory().openSession();
		session.beginTransaction();
		Query<?> query =  session.createQuery(sql);
		int result = query.executeUpdate();
		session.getTransaction().commit();
		session.close();
		
		
		return 1;
	}
}
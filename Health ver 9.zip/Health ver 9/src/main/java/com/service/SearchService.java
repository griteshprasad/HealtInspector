package com.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate5.HibernateTemplate;


import com.pojo.doctor;
 
public class SearchService {

	private HibernateTemplate hibernateTemplate;
	private static Logger log = Logger.getLogger(AuthService.class);

	private SearchService() { }

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@SuppressWarnings( { "unchecked", "deprecation" } )
	public List<doctor> findUser(String specialization,String clinic) {
		
		System.out.println("Inside findUser...");
		String sqlQuery = "from doctor as d where d.specialization=? OR d.clinic=?";
		//String sqlQuery = "from doctor";
		
			List<doctor> userObj = (List<doctor>) hibernateTemplate.find(sqlQuery,specialization, clinic);
			

		    return userObj;
	}
	@SuppressWarnings( { "unchecked", "deprecation" } )
	public List<doctor> findOnlineUser() {
		
		System.out.println("Inside findOnlineUser...");
		String sqlQuery = "from doctor as d where d.status='Active'";
		
		
			List<doctor> userObj = (List<doctor>) hibernateTemplate.find(sqlQuery);
			

		    return userObj;
	}
	
	
	
}
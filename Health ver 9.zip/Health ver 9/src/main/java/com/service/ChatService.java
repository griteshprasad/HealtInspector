package com.service;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate5.HibernateTemplate;


import com.pojo.chat;

public class ChatService {
	
	 private HibernateTemplate hibernateTemplate;
     private static Logger log = Logger.getLogger(RegistrationService.class);
 
     private ChatService() { }
 
     public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
         this.hibernateTemplate = hibernateTemplate;
     }

     
     @SuppressWarnings( { "unchecked", "deprecation" } )
     public boolean chatUser(chat obj)
     {
        
        
        hibernateTemplate.save(obj);
            //hibernateTemplate.getSessionFactory().getCurrentSession().getTransaction().commit();
        
        
        return true;
        
        
     }


}

package com.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


import com.service.AuthService;
import com.service.DocAuthService;

@Controller
@SessionAttributes("user")
public class LoginCtrl {

	@Autowired
	private AuthService authenticateService;	
	
	@Autowired
	private DocAuthService docauthenticateService;
	
	private static Logger log = Logger.getLogger(LoginCtrl.class);

	// Checks if the user credentials are valid or not.
	
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public ModelAndView validateUsr(@RequestParam("username")String username,@RequestParam("password")String password) {
		String msg = "";
		boolean isValid = authenticateService.findUser(username, password);
		log.info("Is user valid?= " + isValid);
		ModelAndView mv= new ModelAndView();
        
		
		if(isValid) {
			
			mv.addObject("user", username);
			mv.setViewName("home");
			return mv;
		} else {
			msg = "Invalid credentials";
			return new ModelAndView("home", "output", msg);
		}
	}
	@RequestMapping(value = "/docvalidate", method = RequestMethod.POST)
	public ModelAndView validateDoctor(@RequestParam("username")String username,@RequestParam("password")String password) {
		String msg = "";
		boolean isValid = docauthenticateService.findDoctor(username, password);
		log.info("Is user valid?= " + isValid);
		ModelAndView mv= new ModelAndView();
        
		
		if(isValid) {
			
			mv.addObject("user", username);
			mv.setViewName("doctorDashboard");
			return mv;
		} else {
			msg = "Invalid credentials";
			return new ModelAndView("doctorDashboard", "output", msg);
		}
	}
	 @RequestMapping(value = "/logout",method=RequestMethod.GET)
     public ModelAndView logout(HttpSession session) {
		 String msg = null;
       session.invalidate();
       ModelAndView mv1= new ModelAndView();
       mv1.addObject("user", msg);
       mv1.setViewName("home");
       return mv1;
     }
  
	
}